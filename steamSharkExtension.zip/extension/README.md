<h1>steamShark</h1>

<!-- HEADER SECTION -->
<nav>
    <a href="#description">Description</a>
    <a href="#features">Features</a>
    <a href="#howItWorks">How It Works</a>
    <a href="#contributing">Contributing</a>
</nav>

<!-- DESCRIPTION -->
<div id="description">
    <!-- HEADER -->
    <div>
        <h2>Description</h2>
    </div>
    <!-- CONTENT -->
    <div>
        steamShark is an extension to prevent scams in the steam ecosytstem
    </div>
</div>

<!-- HOW IT WORKS -->
<div id="features">
    <!-- HEADER -->
    <div>
        <h2>Features</h2>
    </div>
    <!-- CONTENT -->
    <div>
        <ul>
            <li>
            To complete
            </li>
        </ul>
    </div>
</div>

<!-- HOW IT WORKS -->
<div id="howItWorks">
    <!-- HEADER -->
    <div>
        <h2>How It Works?</h2>
    </div>
    <!-- CONTENT -->
    <div>
        To complete
    </div>
</div>

<!-- CONTRIBUTING -->
<div id="contributing">
    <!-- HEADER -->
    <div>
        <h2>Contributing</h2>
    </div>
    <!-- CONTENT -->
    <div>
        <p>
Contributions are always welcome!

See `contributing.md` for ways to get started.

Please adhere to this project's `code of conduct`.
</p>

</div>

</div>

<style>
nav{
    display: flex;
    flex-direction: row;
    gap: 20px;
}
</style>
